// document.getElementById("btn_1").onmouseover = function() {mouseOver()};
// document.getElementById("btn_1").onmouseout = function() {mouseOut()};


// function mouseOver() {
//     document.getElementById("info_profil").innerHTML = "$_SESSION['nom'];" 
// }

// function mouseOut() {
//     document.getElementById("info_profil").innerHTML = "black";
// }