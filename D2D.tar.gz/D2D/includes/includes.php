
<?php
include_once 'connexionDB.php';
$DB = new connexionDB();
?>