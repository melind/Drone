<?php 
session_start();
include('../includes/navbar.php');
include('../includes/includes.php');
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../index.css">
	<title>Drone Racing</title>
</head>
<body>
	<img src="../images/logo.png" id="logo" alt="">


</body>
</html>