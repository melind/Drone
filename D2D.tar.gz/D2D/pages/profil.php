<?php 
session_start();
include('../includes/navbar.php');
include('../includes/includes.php');

$req = $DB->query('SELECT * FROM user');
$req = $req->fetchAll();

$prod = $DB->query('SELECT * FROM product WHERE id_cat = 1');
$prod = $prod->fetchAll();

$cat = $DB->query('SELECT * FROM categories');
$cat = $cat->fetchAll();

foreach ($req as $r) {
	# code...
}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
	<link rel="stylesheet" href="../index.css">
	<title>Drone Racing</title>
</head>
<body>
	<img src="/D2D/images/logo.png" id="logo" alt="">



<div class="container_profil">
	<div class="row">
	  <div class="col-4">
	    <div class="list-group" id="list-tab" role="tablist">
	      <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">PROFIL</a>
	      <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">DERNIERS ACHATS</a>
	      <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">INFORMATIONS DE FACTURATION</a>
		</div>
	  </div>
	  <div class="col-8">
	    <div class="tab-content" id="nav-tabContent">
	      	<div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
				<h3><?php echo $_SESSION['nom']." ".$_SESSION['prenom'];?></h3>


			</div>

	      	<div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
	      		Dernier achats
	      	</div>

	      	<div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
	      		<p>Adresse : <?php echo $_SESSION['adresse'];?></p>
	      		<p>Ville : <?php echo $_SESSION['ville'];?></p>
	      		<p>Code postale : <?php echo $_SESSION['code_postale'];?></p>
	      	</div>
	    </div>
	  </div>
	</div>
</div>



<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
<script src="../index.js"></script>
</body>
</html>